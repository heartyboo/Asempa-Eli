import { Zap, Shield, Clock, Award, Phone, Mail, MapPin, Lightbulb, Factory, Home, Menu, X } from 'lucide-react';
import { useState } from 'react';

function App() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    element?.scrollIntoView({ behavior: 'smooth' });
    setMobileMenuOpen(false);
  };

  return (
    <div className="min-h-screen bg-white">
      <header className="fixed top-0 w-full bg-white/95 backdrop-blur-sm shadow-sm z-50">
        <nav className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Zap className="w-8 h-8 text-amber-500" />
              <div>
                <div className="text-xl font-bold text-gray-900">ASEMMATECH</div>
                <div className="text-xs text-gray-600">COMPANY LIMITED</div>
              </div>
            </div>

            <div className="hidden md:flex items-center space-x-8">
              <button onClick={() => scrollToSection('home')} className="text-gray-700 hover:text-amber-500 transition-colors">Home</button>
              <button onClick={() => scrollToSection('about')} className="text-gray-700 hover:text-amber-500 transition-colors">About</button>
              <button onClick={() => scrollToSection('services')} className="text-gray-700 hover:text-amber-500 transition-colors">Services</button>
              <button onClick={() => scrollToSection('contact')} className="bg-amber-500 text-white px-6 py-2 rounded-lg hover:bg-amber-600 transition-colors">Contact Us</button>
            </div>

            <button onClick={() => setMobileMenuOpen(!mobileMenuOpen)} className="md:hidden">
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>

          {mobileMenuOpen && (
            <div className="md:hidden mt-4 pb-4 space-y-3">
              <button onClick={() => scrollToSection('home')} className="block w-full text-left text-gray-700 hover:text-amber-500 transition-colors">Home</button>
              <button onClick={() => scrollToSection('about')} className="block w-full text-left text-gray-700 hover:text-amber-500 transition-colors">About</button>
              <button onClick={() => scrollToSection('services')} className="block w-full text-left text-gray-700 hover:text-amber-500 transition-colors">Services</button>
              <button onClick={() => scrollToSection('contact')} className="block w-full text-left bg-amber-500 text-white px-6 py-2 rounded-lg hover:bg-amber-600 transition-colors">Contact Us</button>
            </div>
          )}
        </nav>
      </header>

      <main className="pt-20">
        <section id="home" className="relative bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 text-white py-24 md:py-32">
          <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxwYXRoIGQ9Ik0zNiAxOGMzLjMxNCAwIDYgMi42ODYgNiA2cy0yLjY4NiA2LTYgNi02LTIuNjg2LTYtNiAyLjY4Ni02IDYtNiIgc3Ryb2tlPSJyZ2JhKDI1MSwgMTkxLCA4NiwgMC4xKSIvPjwvZz48L3N2Zz4=')] opacity-20"></div>

          <div className="container mx-auto px-6 relative z-10">
            <div className="max-w-3xl">
              <div className="inline-flex items-center space-x-2 bg-amber-500/20 text-amber-400 px-4 py-2 rounded-full mb-6 backdrop-blur-sm">
                <Zap className="w-4 h-4" />
                <span className="text-sm font-medium">Powering Excellence Since Inception</span>
              </div>

              <h1 className="text-5xl md:text-6xl font-bold mb-6 leading-tight">
                Professional Electrical Solutions for
                <span className="text-amber-400"> Modern Infrastructure</span>
              </h1>

              <p className="text-xl text-gray-300 mb-8 leading-relaxed">
                ASEMMATECH COMPANY LIMITED delivers comprehensive electrical engineering services with unwavering commitment to safety, quality, and innovation.
              </p>

              <div className="flex flex-wrap gap-4">
                <button onClick={() => scrollToSection('services')} className="bg-amber-500 text-white px-8 py-4 rounded-lg hover:bg-amber-600 transition-all transform hover:scale-105 font-medium shadow-lg">
                  Our Services
                </button>
                <button onClick={() => scrollToSection('contact')} className="bg-white/10 backdrop-blur-sm text-white px-8 py-4 rounded-lg hover:bg-white/20 transition-all border border-white/20 font-medium">
                  Get In Touch
                </button>
              </div>
            </div>
          </div>

          <div className="absolute bottom-0 left-0 right-0 h-20 bg-gradient-to-t from-white to-transparent"></div>
        </section>

        <section className="py-16 bg-white">
          <div className="container mx-auto px-6">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
              <div className="text-center">
                <div className="text-4xl font-bold text-amber-500 mb-2">500+</div>
                <div className="text-gray-600">Projects Completed</div>
              </div>
              <div className="text-center">
                <div className="text-4xl font-bold text-amber-500 mb-2">98%</div>
                <div className="text-gray-600">Client Satisfaction</div>
              </div>
              <div className="text-center">
                <div className="text-4xl font-bold text-amber-500 mb-2">24/7</div>
                <div className="text-gray-600">Support Available</div>
              </div>
              <div className="text-center">
                <div className="text-4xl font-bold text-amber-500 mb-2">15+</div>
                <div className="text-gray-600">Years Experience</div>
              </div>
            </div>
          </div>
        </section>

        <section id="about" className="py-20 bg-gray-50">
          <div className="container mx-auto px-6">
            <div className="grid md:grid-cols-2 gap-12 items-center">
              <div>
                <div className="inline-block bg-amber-100 text-amber-600 px-4 py-2 rounded-full text-sm font-medium mb-4">
                  About Us
                </div>
                <h2 className="text-4xl font-bold text-gray-900 mb-6">
                  Leading Electrical Contractor in the Industry
                </h2>
                <p className="text-gray-600 mb-6 leading-relaxed text-lg">
                  ASEMMATECH COMPANY LIMITED is a premier electrical engineering firm specializing in comprehensive electrical solutions for residential, commercial, and industrial sectors. Our team of certified electricians and engineers brings years of expertise to every project.
                </p>
                <p className="text-gray-600 mb-8 leading-relaxed text-lg">
                  We pride ourselves on delivering exceptional quality, maintaining the highest safety standards, and providing innovative solutions that meet the evolving needs of our clients.
                </p>

                <div className="space-y-4">
                  <div className="flex items-start space-x-3">
                    <Shield className="w-6 h-6 text-amber-500 flex-shrink-0 mt-1" />
                    <div>
                      <h3 className="font-semibold text-gray-900 mb-1">Certified & Licensed</h3>
                      <p className="text-gray-600">All work performed by fully certified and insured professionals</p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <Award className="w-6 h-6 text-amber-500 flex-shrink-0 mt-1" />
                    <div>
                      <h3 className="font-semibold text-gray-900 mb-1">Quality Guaranteed</h3>
                      <p className="text-gray-600">Comprehensive warranties on all installations and services</p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="bg-white p-6 rounded-xl shadow-lg">
                  <Shield className="w-12 h-12 text-amber-500 mb-4" />
                  <h3 className="font-bold text-gray-900 mb-2">Safety First</h3>
                  <p className="text-gray-600 text-sm">Rigorous safety protocols on every project</p>
                </div>
                <div className="bg-white p-6 rounded-xl shadow-lg mt-8">
                  <Clock className="w-12 h-12 text-amber-500 mb-4" />
                  <h3 className="font-bold text-gray-900 mb-2">On-Time Delivery</h3>
                  <p className="text-gray-600 text-sm">Committed to project timelines</p>
                </div>
                <div className="bg-white p-6 rounded-xl shadow-lg">
                  <Award className="w-12 h-12 text-amber-500 mb-4" />
                  <h3 className="font-bold text-gray-900 mb-2">Expert Team</h3>
                  <p className="text-gray-600 text-sm">Highly skilled professionals</p>
                </div>
                <div className="bg-white p-6 rounded-xl shadow-lg mt-8">
                  <Lightbulb className="w-12 h-12 text-amber-500 mb-4" />
                  <h3 className="font-bold text-gray-900 mb-2">Innovation</h3>
                  <p className="text-gray-600 text-sm">Latest technology & methods</p>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section id="services" className="py-20 bg-white">
          <div className="container mx-auto px-6">
            <div className="text-center mb-16">
              <div className="inline-block bg-amber-100 text-amber-600 px-4 py-2 rounded-full text-sm font-medium mb-4">
                Our Services
              </div>
              <h2 className="text-4xl font-bold text-gray-900 mb-4">
                Comprehensive Electrical Solutions
              </h2>
              <p className="text-gray-600 max-w-2xl mx-auto text-lg">
                From design to installation and maintenance, we provide end-to-end electrical services tailored to your needs
              </p>
            </div>

            <div className="grid md:grid-cols-3 gap-8">
              <div className="group bg-gradient-to-br from-gray-50 to-gray-100 p-8 rounded-2xl hover:shadow-2xl transition-all duration-300 border border-gray-200 hover:border-amber-500">
                <div className="bg-amber-500 w-16 h-16 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                  <Home className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-2xl font-bold text-gray-900 mb-4">Residential Services</h3>
                <p className="text-gray-600 mb-6 leading-relaxed">
                  Complete electrical solutions for homes including wiring, lighting, panel upgrades, and smart home installations.
                </p>
                <ul className="space-y-2 text-gray-700">
                  <li className="flex items-center space-x-2">
                    <Zap className="w-4 h-4 text-amber-500" />
                    <span>House Rewiring</span>
                  </li>
                  <li className="flex items-center space-x-2">
                    <Zap className="w-4 h-4 text-amber-500" />
                    <span>Lighting Design & Installation</span>
                  </li>
                  <li className="flex items-center space-x-2">
                    <Zap className="w-4 h-4 text-amber-500" />
                    <span>Panel Upgrades</span>
                  </li>
                  <li className="flex items-center space-x-2">
                    <Zap className="w-4 h-4 text-amber-500" />
                    <span>Smart Home Systems</span>
                  </li>
                </ul>
              </div>

              <div className="group bg-gradient-to-br from-gray-50 to-gray-100 p-8 rounded-2xl hover:shadow-2xl transition-all duration-300 border border-gray-200 hover:border-amber-500">
                <div className="bg-amber-500 w-16 h-16 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                  <Factory className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-2xl font-bold text-gray-900 mb-4">Commercial Services</h3>
                <p className="text-gray-600 mb-6 leading-relaxed">
                  Reliable electrical services for offices, retail spaces, and commercial buildings with minimal disruption.
                </p>
                <ul className="space-y-2 text-gray-700">
                  <li className="flex items-center space-x-2">
                    <Zap className="w-4 h-4 text-amber-500" />
                    <span>Office Electrical Systems</span>
                  </li>
                  <li className="flex items-center space-x-2">
                    <Zap className="w-4 h-4 text-amber-500" />
                    <span>Emergency Lighting</span>
                  </li>
                  <li className="flex items-center space-x-2">
                    <Zap className="w-4 h-4 text-amber-500" />
                    <span>Data Cabling</span>
                  </li>
                  <li className="flex items-center space-x-2">
                    <Zap className="w-4 h-4 text-amber-500" />
                    <span>Energy Audits</span>
                  </li>
                </ul>
              </div>

              <div className="group bg-gradient-to-br from-gray-50 to-gray-100 p-8 rounded-2xl hover:shadow-2xl transition-all duration-300 border border-gray-200 hover:border-amber-500">
                <div className="bg-amber-500 w-16 h-16 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                  <Zap className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-2xl font-bold text-gray-900 mb-4">Industrial Services</h3>
                <p className="text-gray-600 mb-6 leading-relaxed">
                  Heavy-duty electrical installations and maintenance for manufacturing and industrial facilities.
                </p>
                <ul className="space-y-2 text-gray-700">
                  <li className="flex items-center space-x-2">
                    <Zap className="w-4 h-4 text-amber-500" />
                    <span>Motor Control Systems</span>
                  </li>
                  <li className="flex items-center space-x-2">
                    <Zap className="w-4 h-4 text-amber-500" />
                    <span>Power Distribution</span>
                  </li>
                  <li className="flex items-center space-x-2">
                    <Zap className="w-4 h-4 text-amber-500" />
                    <span>Equipment Installation</span>
                  </li>
                  <li className="flex items-center space-x-2">
                    <Zap className="w-4 h-4 text-amber-500" />
                    <span>Preventive Maintenance</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </section>

        <section className="py-20 bg-gradient-to-br from-slate-900 to-slate-800 text-white">
          <div className="container mx-auto px-6">
            <div className="grid md:grid-cols-3 gap-8">
              <div className="text-center">
                <div className="bg-amber-500/20 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6 backdrop-blur-sm">
                  <Shield className="w-10 h-10 text-amber-400" />
                </div>
                <h3 className="text-2xl font-bold mb-3">Licensed & Insured</h3>
                <p className="text-gray-300 leading-relaxed">
                  Fully licensed, bonded, and insured for your complete peace of mind
                </p>
              </div>

              <div className="text-center">
                <div className="bg-amber-500/20 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6 backdrop-blur-sm">
                  <Clock className="w-10 h-10 text-amber-400" />
                </div>
                <h3 className="text-2xl font-bold mb-3">24/7 Emergency Service</h3>
                <p className="text-gray-300 leading-relaxed">
                  Round-the-clock emergency electrical services when you need us most
                </p>
              </div>

              <div className="text-center">
                <div className="bg-amber-500/20 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6 backdrop-blur-sm">
                  <Award className="w-10 h-10 text-amber-400" />
                </div>
                <h3 className="text-2xl font-bold mb-3">Quality Workmanship</h3>
                <p className="text-gray-300 leading-relaxed">
                  Exceptional quality backed by comprehensive warranties and guarantees
                </p>
              </div>
            </div>
          </div>
        </section>

        <section id="contact" className="py-20 bg-gray-50">
          <div className="container mx-auto px-6">
            <div className="grid md:grid-cols-2 gap-12">
              <div>
                <div className="inline-block bg-amber-100 text-amber-600 px-4 py-2 rounded-full text-sm font-medium mb-4">
                  Contact Us
                </div>
                <h2 className="text-4xl font-bold text-gray-900 mb-6">
                  Get In Touch With Our Team
                </h2>
                <p className="text-gray-600 mb-8 text-lg leading-relaxed">
                  Ready to start your project? Contact ASEMMATECH COMPANY LIMITED today for a free consultation and quote. Our experts are here to help you with all your electrical needs.
                </p>

                <div className="space-y-6">
                  <div className="flex items-start space-x-4">
                    <div className="bg-amber-500 p-3 rounded-lg">
                      <Phone className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-gray-900 mb-1">Phone</h3>
                      <p className="text-gray-600">+233 XX XXX XXXX</p>
                      <p className="text-gray-600">+233 XX XXX XXXX</p>
                    </div>
                  </div>

                  <div className="flex items-start space-x-4">
                    <div className="bg-amber-500 p-3 rounded-lg">
                      <Mail className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-gray-900 mb-1">Email</h3>
                      <p className="text-gray-600">info@asemmatech.com</p>
                      <p className="text-gray-600">contact@asemmatech.com</p>
                    </div>
                  </div>

                  <div className="flex items-start space-x-4">
                    <div className="bg-amber-500 p-3 rounded-lg">
                      <MapPin className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-gray-900 mb-1">Office Location</h3>
                      <p className="text-gray-600">Accra, Ghana</p>
                    </div>
                  </div>
                </div>

                <div className="mt-8 bg-amber-50 border border-amber-200 rounded-xl p-6">
                  <h3 className="font-bold text-gray-900 mb-2">Business Hours</h3>
                  <div className="space-y-1 text-gray-700">
                    <p>Monday - Friday: 8:00 AM - 6:00 PM</p>
                    <p>Saturday: 9:00 AM - 4:00 PM</p>
                    <p>Sunday: Emergency Service Only</p>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-2xl shadow-xl p-8">
                <h3 className="text-2xl font-bold text-gray-900 mb-6">Request a Quote</h3>
                <form className="space-y-6">
                  <div>
                    <label className="block text-gray-700 font-medium mb-2">Full Name</label>
                    <input
                      type="text"
                      className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:border-amber-500 focus:ring-2 focus:ring-amber-200 outline-none transition-all"
                      placeholder="John Doe"
                    />
                  </div>

                  <div>
                    <label className="block text-gray-700 font-medium mb-2">Email Address</label>
                    <input
                      type="email"
                      className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:border-amber-500 focus:ring-2 focus:ring-amber-200 outline-none transition-all"
                      placeholder="john@example.com"
                    />
                  </div>

                  <div>
                    <label className="block text-gray-700 font-medium mb-2">Phone Number</label>
                    <input
                      type="tel"
                      className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:border-amber-500 focus:ring-2 focus:ring-amber-200 outline-none transition-all"
                      placeholder="+233 XX XXX XXXX"
                    />
                  </div>

                  <div>
                    <label className="block text-gray-700 font-medium mb-2">Service Type</label>
                    <select className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:border-amber-500 focus:ring-2 focus:ring-amber-200 outline-none transition-all">
                      <option>Select a service</option>
                      <option>Residential Electrical</option>
                      <option>Commercial Electrical</option>
                      <option>Industrial Electrical</option>
                      <option>Emergency Service</option>
                      <option>Maintenance</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-gray-700 font-medium mb-2">Message</label>
                    <textarea
                      rows={4}
                      className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:border-amber-500 focus:ring-2 focus:ring-amber-200 outline-none transition-all resize-none"
                      placeholder="Tell us about your project..."
                    ></textarea>
                  </div>

                  <button
                    type="submit"
                    className="w-full bg-amber-500 text-white py-4 rounded-lg hover:bg-amber-600 transition-colors font-medium text-lg shadow-lg hover:shadow-xl"
                  >
                    Submit Request
                  </button>
                </form>
              </div>
            </div>
          </div>
        </section>
      </main>

      <footer className="bg-slate-900 text-white py-12">
        <div className="container mx-auto px-6">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <Zap className="w-8 h-8 text-amber-500" />
                <div>
                  <div className="text-lg font-bold">ASEMMATECH</div>
                  <div className="text-xs text-gray-400">COMPANY LIMITED</div>
                </div>
              </div>
              <p className="text-gray-400 text-sm leading-relaxed">
                Professional electrical solutions delivering excellence, safety, and innovation to every project.
              </p>
            </div>

            <div>
              <h4 className="font-bold mb-4">Quick Links</h4>
              <ul className="space-y-2 text-gray-400 text-sm">
                <li><button onClick={() => scrollToSection('home')} className="hover:text-amber-500 transition-colors">Home</button></li>
                <li><button onClick={() => scrollToSection('about')} className="hover:text-amber-500 transition-colors">About Us</button></li>
                <li><button onClick={() => scrollToSection('services')} className="hover:text-amber-500 transition-colors">Services</button></li>
                <li><button onClick={() => scrollToSection('contact')} className="hover:text-amber-500 transition-colors">Contact</button></li>
              </ul>
            </div>

            <div>
              <h4 className="font-bold mb-4">Services</h4>
              <ul className="space-y-2 text-gray-400 text-sm">
                <li>Residential Electrical</li>
                <li>Commercial Electrical</li>
                <li>Industrial Electrical</li>
                <li>Emergency Service</li>
              </ul>
            </div>

            <div>
              <h4 className="font-bold mb-4">Contact Info</h4>
              <ul className="space-y-2 text-gray-400 text-sm">
                <li>Accra, Ghana</li>
                <li>+233 XX XXX XXXX</li>
                <li>info@asemmatech.com</li>
              </ul>
            </div>
          </div>

          <div className="border-t border-gray-800 pt-8 text-center text-gray-400 text-sm">
            <p>&copy; {new Date().getFullYear()} ASEMMATECH COMPANY LIMITED. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;
